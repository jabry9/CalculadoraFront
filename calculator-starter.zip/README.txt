A Pen created at CodePen.io. You can find this one at https://codepen.io/zellwk/pen/pLgmGL.

 This is the starter file for a blog post "How to build a calculator". You can follow the lesson at https://zellwk.com/blog/calculator-part-1